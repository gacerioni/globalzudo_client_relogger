local warTab = addTab("HP") -- Add new tab called War

-- config

local Spells = {
    {name = "frenzy", cast = true, range = 3, manaCost = 300, level = 110},
    --{name = "exeta res", cast = true, range = 1, manaCost = 40, level =20},
    {name = "exori gran", cast = true, range = 1, manaCost = 290, level = 60},
    {name = "exori", cast = true, range = 1, manaCost = 300, level = 110},
}

-- script

macro(500, "Spells Para Upar", function()

    if not g_game.isAttacking() then
     return
    end

    local target = g_game.getAttackingCreature()
    local distance = getDistanceBetween(player:getPosition(), target:getPosition())

    for _, spell in ipairs(Spells) do
     if mana() >= spell.manaCost and lvl() >= spell.level and distance <= spell.range and spell.cast then
      if not hasPartyBuff() or not spell.buffSpell then
       say(spell.name)
      end
     end
    end

end, warTab)


-- config

local Spells = {
    {name = "exori gran", cast = true, range = 3, manaCost = 290, level = 60},
    {name = "exori", cast = true, range = 3, manaCost = 300, level = 110},
}

-- script

macro(500, "Spells War", function()

    if not g_game.isAttacking() then
     return
    end

    local target = g_game.getAttackingCreature()
    local distance = getDistanceBetween(player:getPosition(), target:getPosition())

    for _, spell in ipairs(Spells) do
     if mana() >= spell.manaCost and lvl() >= spell.level and distance <= spell.range and spell.cast then
      if not hasPartyBuff() or not spell.buffSpell then
       say(spell.name)
      end
     end
    end

end, warTab)