macro(60000, function()
    turn(math.random(0,3))
end)