-- main tab
UI.Label("Vithrax CFG v1.2 \n \n Scripting Service: \n Vithrax#5814")

UI.Separator()



