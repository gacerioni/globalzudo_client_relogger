--AUTO IMBUIMENT--
setDefaultTab("TOOLS")
addSeparator()

local txtImbuis = UI.Label()
txtImbuis:setColor("green")
txtImbuis:setText("Comprar Imbuiments")

UI.Button("LIFE DRAIN", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(9633, 15) end)
    schedule(3000, function() NPC.buy(9685, 25) end)
    schedule(4000, function() NPC.buy(9663, 5) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("MANA DRAIN", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(11492, 25) end)
    schedule(3000, function() NPC.buy(20200, 25) end)
    schedule(4000, function() NPC.buy(22730, 5) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("SKILL SWORD", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(9691, 25) end)
    schedule(3000, function() NPC.buy(21202, 25) end)
    schedule(4000, function() NPC.buy(9654, 5) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("SKILL DISTANCE", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(11464, 25) end)
    schedule(3000, function() NPC.buy(18994, 20) end)
    schedule(4000, function() NPC.buy(10298, 10) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DEF DEATH", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(11466, 25) end)
    schedule(3000, function() NPC.buy(22007, 20) end)
    schedule(4000, function() NPC.buy(9660, 5) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DEF FIRE", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(5877, 20) end)
    schedule(3000, function() NPC.buy(16131, 10) end)
    schedule(4000, function() NPC.buy(11658, 5) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DEF ICE", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(10295, 25) end)
    schedule(3000, function() NPC.buy(10307, 15) end)
    schedule(4000, function() NPC.buy(14012, 5) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DEF EARTH", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(17823, 25) end)
    schedule(3000, function() NPC.buy(9694, 20) end)
    schedule(4000, function() NPC.buy(11702, 10) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DEF ENERGY", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(9644, 20) end)
    schedule(3000, function() NPC.buy(14079, 15) end)
    schedule(4000, function() NPC.buy(9665, 10) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DEF HOLY x1 ", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(9639, 25) end)
    schedule(3000, function() NPC.buy(9638, 25) end)
    schedule(4000, function() NPC.buy(10304, 20) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("SKILL ML", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(9635, 25) end)
    schedule(3000, function() NPC.buy(11452, 15) end)
    schedule(4000, function() NPC.buy(10309, 15) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("SKILL SHIELD", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(9641, 20) end)
    schedule(3000, function() NPC.buy(11703, 25) end)
    schedule(4000, function() NPC.buy(20199, 25) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("SKILL CRITICAL", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(11444, 20) end)
    schedule(3000, function() NPC.buy(10311, 25) end)
    schedule(4000, function() NPC.buy(22728, 5) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DMG DEATH", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(11484, 25) end)
    schedule(3000, function() NPC.buy(9647, 20) end)
    schedule(4000, function() NPC.buy(10420, 5) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DMG FIRE", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(9636, 25) end)
    schedule(3000, function() NPC.buy(5920, 5) end)
    schedule(4000, function() NPC.buy(5954, 5) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DMG ICE", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(9661, 25) end)
    schedule(3000, function() NPC.buy(21801, 10) end)
    schedule(4000, function() NPC.buy(9650, 5) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DMG EARTH", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(9686, 25) end)
    schedule(3000, function() NPC.buy(9640, 20) end)
    schedule(4000, function() NPC.buy(21194, 2) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("DMG ENERGY", function()
  NPC.say("hi")
  schedule(1000, function() NPC.say("trade") end)
  if NPC.isTradeOpen then
    schedule(2000, function() NPC.buy(18993, 25) end)
    schedule(3000, function() NPC.buy(21975, 5) end)
    schedule(4000, function() NPC.buy(23508, 1) end)
  end
  schedule(5000, function() NPC.closeTrade() end)
  schedule(6000, function() NPC.say("bye") end)
end)

UI.Button("SUP HP", function()
    NPC.say("hi")
    schedule(1000, function() NPC.say("trade") end)
    if NPC.isTradeOpen then
      schedule(2000, function() NPC.buy(23375, 100) end)
      schedule(3000, function() NPC.buy(23375, 100) end)
      schedule(4000, function() NPC.buy(23375, 100) end)
      schedule(4000, function() NPC.buy(23375, 100) end)
      schedule(5000, function() NPC.buy(23375, 100) end)
      schedule(6000, function() NPC.buy(23375, 100) end)
      schedule(7000, function() NPC.buy(23375, 100) end)
      schedule(8000, function() NPC.buy(23375, 100) end)
      schedule(9000, function() NPC.buy(23375, 100) end)
      schedule(10000, function() NPC.buy(23375, 100) end)
      schedule(11000, function() NPC.buy(23375, 100) end)
      schedule(12000, function() NPC.buy(23375, 100) end)
      schedule(13000, function() NPC.buy(23375, 100) end)
      schedule(14000, function() NPC.buy(23375, 100) end)
      schedule(15000, function() NPC.buy(23375, 100) end)
      schedule(16000, function() NPC.buy(23375, 100) end)
      schedule(17000, function() NPC.buy(23375, 100) end)
      schedule(18000, function() NPC.buy(23375, 100) end)
    end
    schedule(5000, function() NPC.closeTrade() end)
    schedule(6000, function() NPC.say("bye") end)
  end)