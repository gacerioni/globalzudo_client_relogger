-- -- tools tab
-- setDefaultTab("Tools")

-- -- allows to test/edit bot lua scripts ingame, you can have multiple scripts like this, just change storage.ingame_lua
-- UI.Button("Ingame hotkey editor", function(newText)
--   UI.MultilineEditorWindow(storage.ingame_hotkeys or "", {title="Hotkeys editor", description="You can add your custom hotkeys/singlehotkeys here"}, function(text)
--     storage.ingame_hotkeys = text
--     reload()
--   end)
-- end)

-- UI.Separator()

-- for _, scripts in pairs({storage.ingame_hotkeys}) do
--   if type(scripts) == "string" and scripts:len() > 3 then
--     local status, result = pcall(function()
--       assert(load(scripts, "ingame_editor"))()
--     end)
--     if not status then 
--       error("Ingame edior error:\n" .. result)
--     end
--   end
-- end

-- UI.Separator()

-- local moneyIds = {3031, 3035} -- gold coin, platinium coin
-- macro(1000, "Exchange money", function()
--   local containers = g_game.getContainers()
--   for index, container in pairs(containers) do
--     if not container.lootContainer then -- ignore monster containers
--       for i, item in ipairs(container:getItems()) do
--         if item:getCount() == 100 then
--           for m, moneyId in ipairs(moneyIds) do
--             if item:getId() == moneyId then
--               return g_game.use(item)            
--             end
--           end
--         end
--       end
--     end
--   end
-- end)

-- UI.Separator()

-- macro(60000, "Send message on trade", function()
--   local trade = getChannelId("advertising")
--   if not trade then
--     trade = getChannelId("trade")
--   end
--   if trade and storage.autoTradeMessage:len() > 0 then    
--     sayChannel(trade, storage.autoTradeMessage)
--   end
-- end)
-- UI.TextEdit(storage.autoTradeMessage or "I'm using OTClientV8!", function(widget, text)    
--   storage.autoTradeMessage = text
-- end)

-- UI.Separator()
