setDefaultTab("HP")
function jewelleryEquip()
  panelName = "jewelleryEquipper"
 
  local ui = setupUI([[
Panel
  height: 108
  margin-top: 2

  BotItem
    id: idAmmy
    anchors.left: parent.left
    anchors.top: parent.top

  BotItem
    id: defaultIdAmmy
    anchors.left: parent.left
    anchors.top: parent.top
    margin-left: 36

  BotLabel
    id: ammyTitle
    anchors.left: defaultIdAmmy.right
    anchors.right: parent.right
    anchors.top: parent.top
    text-align: center
    text: Equip Amulet

  SmallBotSwitch
    id: ammySwitch
    anchors.left: defaultIdAmmy.right
    anchors.right: parent.right
    anchors.top: parent.top
    margin-left: 3
    margin-right: 3
    margin-top: 18

  HorizontalScrollBar
    id: ammyScroll1
    anchors.left: parent.left
    anchors.top: defaultIdAmmy.bottom
    anchors.right: parent.right
    margin-right: 2
    margin-left: 2
    margin-top: 5
    minimum: 0
    maximum: 100
    step: 1

  BotItem
    id: idRing
    anchors.left: parent.left
    anchors.top: ammyScroll1.bottom
    margin-top: 5

  BotItem
    id: defaultIdRing
    anchors.left: parent.left
    anchors.top: ammyScroll1.bottom
    margin-top: 5
    margin-left: 36

  BotLabel
    id: ringTitle
    anchors.left: defaultIdRing.right
    anchors.right: parent.right
    anchors.top: ammyScroll1.top
    text-align: center
    text: Equip Ring
    margin-top: 20

  SmallBotSwitch
    id: ringSwitch
    anchors.left: defaultIdRing.right
    anchors.right: parent.right
    anchors.top: ammyScroll1.top
    margin-left: 3
    margin-right: 3
    margin-top: 36

  HorizontalScrollBar
    id: ringScroll1
    anchors.left: parent.left
    anchors.top: defaultIdRing.bottom
    anchors.right: parent.right
    margin-right: 2
    margin-left: 2
    margin-top: 5
    minimum: 0
    maximum: 100
    step: 1

  ]], parent)
  ui:setId(panelName)
  if not storage[panelName] or not storage[panelName].idRing or not storage[panelName].defaultIdRing or not storage[panelName].idAmmy or not storage[panelName].defaultIdAmmy then
    storage[panelName] = {
      ringSwitch = true,
      ammySwitch = true,
      idRing = 3051,
      defaultIdRing = 34080,
      idAmmy = 3081,
      defaultIdAmmy = 10476,
      ringMin = 70,
      ammyMin = 75,
      ringValor = "HP",
      ammyValor = "HP"
    }
  end

  local ammyItem = Item.create(storage[panelName].idAmmy)
  local ammyDefaultItem = Item.create(storage[panelName].defaultIdAmmy)
  local ringItem = Item.create(storage[panelName].idRing)
  local ringDefaultItem = Item.create(storage[panelName].defaultIdRing)

  ui.ringSwitch:setOn(storage[panelName].ringEnabled)
  ui.ringSwitch.onClick = function(widget)
    storage[panelName].ringEnabled = not storage[panelName].ringEnabled
    widget:setOn(storage[panelName].ringEnabled)
  end
  ui.ammySwitch:setOn(storage[panelName].ammyEnabled)
  ui.ammySwitch.onClick = function(widget)
    storage[panelName].ammyEnabled = not storage[panelName].ammyEnabled
    widget:setOn(storage[panelName].ammyEnabled)
  end

  local updateRingText = function()
    ui.ringSwitch:setText(storage[panelName].ringValor .. "% <= " .. storage[panelName].ringMin .. "%")
  end
  
  local updateAmmyText = function()
    ui.ammySwitch:setText(storage[panelName].ammyValor .. "% <= " .. storage[panelName].ammyMin .. "%")
  end
  
  ui.ringScroll1.onValueChange = function(scroll, value)
    storage[panelName].ringMin = value
    updateRingText()
  end

  ui.ammyScroll1.onValueChange = function(scroll, value)
    storage[panelName].ammyMin = value
    updateAmmyText()
  end 

  ui.idRing.onItemChange = function(widget)
    storage[panelName].idRing = widget:getItemId()
    ringItem = Item.create(storage[panelName].idRing)
  end

  ui.idAmmy.onItemChange = function(widget)
    storage[panelName].idAmmy = widget:getItemId()
    ammyItem = Item.create(storage[panelName].idAmmy)
  end

  ui.defaultIdRing.onItemChange = function(widget)
    storage[panelName].defaultIdRing = widget:getItemId()
    ringDefaultItem = Item.create(storage[panelName].defaultIdRing)
  end

  ui.defaultIdAmmy.onItemChange = function(widget)
    storage[panelName].defaultIdAmmy = widget:getItemId()
    ammyDefaultItem = Item.create(storage[panelName].defaultIdAmmy)
  end

  ui.ringScroll1:setValue(storage[panelName].ringMin)
  ui.ammyScroll1:setValue(storage[panelName].ammyMin)
  ui.idRing:setItemId(storage[panelName].idRing)
  ui.idAmmy:setItemId(storage[panelName].idAmmy)
  ui.defaultIdRing:setItemId(storage[panelName].defaultIdRing)
  ui.defaultIdAmmy:setItemId(storage[panelName].defaultIdAmmy)


local getActiveItemId = function(id)
  if not id then
      return false
  end

  if id == 3049 then
      return 3086
  elseif id == 3050 then
      return 3087
  elseif id == 3051 then
      return 3088
  elseif id == 3052 then
      return 3089
  elseif id == 3053 then
      return 3090
  elseif id == 3091 then
      return 3094
  elseif id == 3092 then
      return 3095
  elseif id == 3093 then
      return 3096
  elseif id == 3097 then
      return 3099
  elseif id == 3098 then
      return 3100
  elseif id == 16114 then
      return 16264
  elseif id == 23531 then
      return 23532
  elseif id == 23533 then
      return 23534
  elseif id == 23529 then
      return  23530
  else
      return id
  end
end

  macro(250, function()

    if not storage[panelName].ammyEnabled then return end

    if storage[panelName].ammyEnabled then 
      if not getNeck() or getNeck():getId() ~= getActiveItemId(storage[panelName].idAmmy) and (hppercent() <= storage[panelName].ammyMin) then
        g_game.equipItem(ammyItem)
      elseif getNeck() and getNeck():getId() ~= getActiveItemId(storage[panelName].defaultIdAmmy) and (hppercent() > storage[panelName].ammyMin) then
        g_game.equipItem(ammyDefaultItem)
      end
    end
  end)

  macro(250, function()
    if not storage[panelName].ringEnabled  then return end

    if not getFinger() or getFinger():getId() ~= getActiveItemId(storage[panelName].idRing) and (hppercent() <= storage[panelName].ringMin) then
      g_game.equipItem(ringItem)
    elseif getFinger() and getFinger():getId() ~= getActiveItemId(storage[panelName].defaultIdRing) and (hppercent() > storage[panelName].ringMin) then
      g_game.equipItem(ringDefaultItem)
    end
  end)

end
addSeparator()
jewelleryEquip()
addSeparator()